books = {}
content =[]

def loadInventory():
    inventory = open('inventory.dat','r')
    for line in inventory:
        global books 
        content = line.split(',')
        books[content[0]] = [content[1],content[2],int(content[3])]
    
    inventory.close() 

def saveInventory(books):
    inventoryList = books
    inventory = open('inventory.dat','w')
    for k,v in inventoryList.items():
        inventory.write(str(k)+','+str(v[0])+','+str(v[1])+','+str(v[2])+'\n')

    inventory.close()



